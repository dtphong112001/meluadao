import React from 'react';
import './App.css';

function App() {
  return (
    <div className="App">
      <h1>🐾 MÈ LỪA ĐẢO 🐾</h1>
      <p>Bán mè (mè đen, mè trắng, mè rang) – uy tín như lời đồn!</p>
      <button onClick={() => alert('Cảm ơn bạn đã bị lừa 😹')}>Mua mè</button>
    </div>
  );
}

export default App;